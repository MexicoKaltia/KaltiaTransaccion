package com.kaltia.kaltiatransaccion.Edicion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdicionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdicionApplication.class, args);
	}
}
